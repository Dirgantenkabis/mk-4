import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.makankuy_project.EditOrderActivity
import com.example.makankuy_project.PesananItem
import com.example.makankuy_project.databinding.ItemPesananBinding

class PesananAdapter(
    private val listPesanan: MutableList<PesananItem>,
    private val onDeleteClick: (Int) -> Unit,
    private val onEditClick: (Int) -> Unit
) : RecyclerView.Adapter<PesananAdapter.PesananViewHolder>() {

    inner class PesananViewHolder(val binding: ItemPesananBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PesananViewHolder {
        val binding = ItemPesananBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PesananViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PesananViewHolder, position: Int) {
        val item = listPesanan[position]

        holder.binding.textNamaPesanan.text = item.nama
        holder.binding.textJumlahPesanan.text = item.jumlah
        holder.binding.imagePesanan.setImageResource(item.gambar)

        // Klik edit
        holder.itemView.setOnClickListener {
            onEditClick(position)
        }

        // Long click delete
        holder.itemView.setOnLongClickListener {
            onDeleteClick(position)
            true
        }
    }

    override fun getItemCount(): Int = listPesanan.size
}