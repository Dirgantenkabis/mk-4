package com.example.makankuy_project

data class PesananItem(
    val nama: String,
    val jumlah: String,
    val gambar: Int
)
