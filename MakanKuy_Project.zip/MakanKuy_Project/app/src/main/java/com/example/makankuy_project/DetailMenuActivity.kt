package com.example.makankuy_project

import android.content.Context
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.makankuy_project.databinding.ActivityDetailMenuBinding

class DetailMenuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailMenuBinding
    private var gambarMenu: Int = 0
    private var namaMenu: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ambil data dari intent
        namaMenu = intent.getStringExtra("nama_menu") ?: ""
        val descMenu = intent.getStringExtra("desc_menu") ?: ""
        gambarMenu = intent.getIntExtra("gambar_menu", R.drawable.ic_makanan_default)

        // Set data ke layout
        binding.textNamaMenu.text = namaMenu
        binding.textDeskripsiMenu.text = descMenu
        binding.imageMenu.setImageResource(gambarMenu)

        // Default jumlah 1
        var jumlah = 1
        binding.textJumlah.text = jumlah.toString()

        binding.btnTambah.setOnClickListener {
            jumlah++
            binding.textJumlah.text = jumlah.toString()
        }

        binding.btnKurang.setOnClickListener {
            if (jumlah > 1) {
                jumlah--
                binding.textJumlah.text = jumlah.toString()
            }
        }

        // Tombol Tambah Pesanan
        binding.btnTambahPesanan.setOnClickListener {
            tambahKePesanan(namaMenu, jumlah.toString(), gambarMenu)
            finish() // kembali otomatis
        }
    }

    private fun tambahKePesanan(nama: String, jumlah: String, gambar: Int) {
        val prefs = getSharedPreferences("data_pesanan", Context.MODE_PRIVATE)

        val setExisting = prefs.getStringSet("list_pesanan", emptySet())?.toMutableSet()
            ?: mutableSetOf()

        // Format penyimpanan
        val dataString = "$nama|$jumlah|$gambar"

        setExisting.add(dataString)

        prefs.edit().putStringSet("list_pesanan", setExisting).apply()
    }
}
