package com.example.makankuy_project

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MenuItem(
    val nama: String,
    val harga: String,
    val gambar: Int,
    val deskripsi: String
) : Parcelable
