package com.example.makankuy_project

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.makankuy_project.databinding.ActivityEditOrderBinding

class EditOrderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditOrderBinding
    private var posisi = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ambil data dari intent
        val nama = intent.getStringExtra("nama") ?: ""
        val jumlah = intent.getStringExtra("jumlah") ?: ""
        posisi = intent.getIntExtra("posisi", -1)

        // Tampilkan ke EditText
        binding.etEditNama.setText(nama)
        binding.etEditJumlah.setText(jumlah)

        // Tombol simpan edit
        binding.btnSimpanEdit.setOnClickListener {
            val namaBaru = binding.etEditNama.text.toString()
            val jumlahBaru = binding.etEditJumlah.text.toString()

            if (namaBaru.isEmpty() || jumlahBaru.isEmpty()) {
                Toast.makeText(this, "Isi semua dulu bre", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Ambil data lama dari SharedPreferences
            val prefs = getSharedPreferences("data_pesanan", MODE_PRIVATE)
            val setPesanan = prefs.getStringSet("list_pesanan", mutableSetOf())!!.toMutableList()

            // Edit item lama
            if (posisi >= 0 && posisi < setPesanan.size) {
                val item = setPesanan[posisi].split("|")
                val gambar = item.getOrNull(2) ?: "0"

                setPesanan[posisi] = "$namaBaru|$jumlahBaru|$gambar"
            }

            // Simpan ulang
            prefs.edit().putStringSet("list_pesanan", setPesanan.toSet()).apply()

            Toast.makeText(this, "Berhasil di-edit!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
