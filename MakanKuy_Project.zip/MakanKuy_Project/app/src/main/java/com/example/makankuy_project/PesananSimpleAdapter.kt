package com.example.makankuy_project

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.makankuy_project.databinding.ItemPesananSimpleBinding

class PesananSimpleAdapter(
    private val listPesanan: List<String>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<PesananSimpleAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemPesananSimpleBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(pesanan: String, position: Int) {
            binding.tvPesanan.text = pesanan

            binding.root.setOnLongClickListener {
                onDelete(position)
                true
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemPesananSimpleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount() = listPesanan.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listPesanan[position], position)
    }
}
