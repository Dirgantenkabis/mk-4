package com.example.makankuy_project

import PesananAdapter
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.makankuy_project.databinding.ActivityOrderBinding

class OrderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOrderBinding
    private lateinit var adapter: PesananAdapter
    private lateinit var listPesanan: MutableList<PesananItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ambil data dari SharedPreferences
        val prefs = getSharedPreferences("data_pesanan", MODE_PRIVATE)
        val setPesanan = prefs.getStringSet("list_pesanan", emptySet()) ?: emptySet()

        // Convert String ke Model
        listPesanan = setPesanan.map { data ->
            val split = data.split("|")
            PesananItem(
                nama = split.getOrNull(0) ?: "",
                jumlah = split.getOrNull(1) ?: "",
                gambar = split.getOrNull(2)?.toIntOrNull() ?: R.drawable.ic_makanan_default
            )
        }.toMutableList()

        // === SETUP RECYCLER ===
        binding.recyclerViewPesanan.layoutManager = LinearLayoutManager(this)

        adapter = PesananAdapter(
            listPesanan,
            onDeleteClick = { pos ->
                if (pos in listPesanan.indices) {

                    // Hapus item
                    listPesanan.removeAt(pos)

                    // Simpan ulang
                    val newSet = listPesanan.map {
                        "${it.nama}|${it.jumlah}|${it.gambar}"
                    }.toSet()

                    prefs.edit().putStringSet("list_pesanan", newSet).apply()

                    adapter.notifyItemRemoved(pos)
                }
            },
            onEditClick = { pos ->
                val intent = Intent(this, EditOrderActivity::class.java)
                intent.putExtra("index", pos)
                intent.putExtra("nama", listPesanan[pos].nama)
                intent.putExtra("jumlah", listPesanan[pos].jumlah)
                intent.putExtra("gambar", listPesanan[pos].gambar)
                startActivity(intent)
            }
        )

        binding.recyclerViewPesanan.adapter = adapter

        // Tombol Tambah
        binding.btnTambahPesanan.setOnClickListener {
            startActivity(Intent(this, AddOrderActivity::class.java))
        }

        // Tombol Kembali
        binding.btnKembali.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
