package com.example.makankuy_project

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.makankuy_project.databinding.ActivityAddOrderBinding

class AddOrderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddOrderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSimpanPesanan.setOnClickListener {
            val namaMenu = binding.etNamaMenu.text.toString()
            val jumlah = binding.etJumlah.text.toString()

            if (namaMenu.isNotEmpty() && jumlah.isNotEmpty()) {
                // Simpan ke SharedPreferences
                val prefs = getSharedPreferences("data_pesanan", MODE_PRIVATE)
                val setPesanan = prefs.getStringSet("list_pesanan", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
                setPesanan.add("$namaMenu - $jumlah")

                prefs.edit().putStringSet("list_pesanan", setPesanan).apply()

                Toast.makeText(this, "Pesanan disimpan!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, OrderActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Isi semua kolom dulu ya!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}