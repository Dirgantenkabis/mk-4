package com.example.makankuy_project

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.makankuy_project.databinding.ItemMenuBinding

class MenuAdapter(
    private val listMenu: List<MenuItem>
) : RecyclerView.Adapter<MenuAdapter.MenuViewHolder>() {

    inner class MenuViewHolder(val binding: ItemMenuBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuViewHolder {
        val binding = ItemMenuBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MenuViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MenuViewHolder, position: Int) {
        val menu = listMenu[position]

        // Set data
        holder.binding.textNamaMenu.text = menu.nama
        holder.binding.textHargaMenu.text = menu.harga
        holder.binding.imageMenu.setImageResource(menu.gambar)

        // === CLICK KE DETAIL MENU ===
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailMenuActivity::class.java)

            intent.putExtra("nama_menu", menu.nama)
            intent.putExtra("desc_menu", menu.deskripsi) gcg//././././////////////////////////////.,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, 
            intent.putExtra("gambar_menu", menu.gambar)

            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = listMenu.size
}
