package com.example.makankuy_project

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.makankuy_project.databinding.ActivityMenuBinding

class MenuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // pakai drawable yang umum ada di project baru
        val daftarMenu = listOf(
            MenuItem("Nasi Goreng Spesial", "Rp 20.000", R.drawable.nasgor, "Nasi goreng spesial"),
            MenuItem("Mie Ayam Bakso", "Rp 18.000", R.drawable.miayam, "Mie ayam + bakso"),
            MenuItem("Ayam Geprek", "Rp 22.000", R.drawable.ayam, "Ayam geprek pedas"),
            MenuItem("Es Teh Manis", "Rp 5.000", R.drawable.esteh, "Es teh manis dingin"),
            MenuItem("Lemon Tea", "Rp 10.000", R.drawable.lemontea, "Lemon Tea")
        )

        val adapter = MenuAdapter(daftarMenu)
        binding.recyclerViewMenu.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewMenu.adapter = adapter
    }
}
